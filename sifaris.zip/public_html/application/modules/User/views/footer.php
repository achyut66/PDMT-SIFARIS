<!-- <script src="--><?//=base_url()?><!--assets/bower_components/jquery/dist/jquery.min.js"></script> -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script> -->
<!-- <script src="<?=base_url()?>assets/js/admin.js"></script> -->
<script src="<?=base_url()?>assets/js/popper.min.js"></script>
<script src="<?=base_url()?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/bower_components/select2/dist/js/select2.min.js"></script>
<script src="<?= base_url()?>assets/calendar/nepali.datepicker.v2.1.min.js"></script>
<script src="<?=base_url()?>assets/calendar/js/nepalidate.js"></script>
<script src="<?=base_url()?>assets/js/frontend.js"></script>
</body>
</html>
